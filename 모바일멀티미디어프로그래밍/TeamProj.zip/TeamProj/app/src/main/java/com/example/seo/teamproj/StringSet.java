package com.example.seo.teamproj;

public class StringSet {
    /* Directory For Image Files */
    public static final String FIRST_DIR="MyDrawing";
    public static final String PICTURE_DIR="Picture";
    public static final String STICKER ="Sticker";

    /* String For MainActivity */
    public static final String PICTURE_FILE_FORM=".png";
    public static final String SHARED_PREF_NAME="LastImage";
    public static final String SHARED_PREF_KEY="imagePath";

    /* String For Sticker */
    public static final String STICKER_ORDER ="order.txt";
    public static final String STICKER_NAME ="b_";
    public static final String STICKER_FILE_FORM =".png";

    /* String For Gallery */
    public static final String URI_STR="content://";
    public static final String INTENT_SET_NAME="sms_body";
    public static final String INTENT_SET_VAL="sendmsg";

    /* Intent ID */
    public static final String INTENT_STICKER ="STICKER";
    public static final String INTENT_PICTURE="IMAGE_NAME";

    /* IntentType For Going Phone Gallery */
    public static final String INTENT_TYPE="image/*";
}
