package com.example.seo.teamproj;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/*
갤러리에 사용될 GridViewFragment
 */
public class Gallery_GridViewFragment extends Fragment {
    public static final int GRIDVIEW=0;
    final int REQ_CODE_SELECT_IMAGE=10;

    View view;
    GridView gridView;
    Intent albumIntent=null;
    int contextPosition;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("JHSS", "framgelayout oncreate");
        view=inflater.inflate(R.layout.fragment_gallery__grid_view, null);
        gridView=(GridView)view.findViewById(R.id.GridView01);
        //gridView.setAdapter(new ImageAdapter(getActivity(), GRIDVIEW));

        albumIntent=new Intent(Intent.ACTION_PICK);
        albumIntent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        albumIntent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        //gridview에 contextmenu달기
        registerForContextMenu(gridView);

        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                //길게 눌렀을경우 '+'라면 contextmenu를 생성하지 않음
                if(adapterView.getCount()==(position+1)){
                    unregisterForContextMenu(gridView);
                }
                else{
                    registerForContextMenu(gridView);
                }
                return false;
            }
        });

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                //'+'를 선택했을경우 그림판 액티비티로
                if(adapterView.getCount()==(position+1)){
                    startActivityForResult(albumIntent, REQ_CODE_SELECT_IMAGE);
                    Log.d("JHSS", "gridview onclicklistener");
                }
            }
        });
        return view;
    }

    //Context Menu 생성
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        if(v==gridView)
        {
            menu.setHeaderTitle(R.string.headerTitle);
            menu.add(0,1,0, R.string.gallery_menu_share);
            menu.add(0,2,0, R.string.gallery_menu_retouch);
            contextPosition=((AdapterView.AdapterContextMenuInfo)menuInfo).position;
        }
    }

    //Context Menu 세부 설정
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Intent intent=null;
        GalleryActivity ga=new GalleryActivity();


        switch (item.getItemId())
        {
            case 1:

                intent=new Intent(Intent.ACTION_SEND);

                String path=ga.putImagePath().get(contextPosition);
                Uri uri=Uri.parse(StringSet.URI_STR+path);
                intent.putExtra(StringSet.INTENT_SET_NAME,StringSet.INTENT_SET_VAL);
                intent.putExtra(Intent.EXTRA_STREAM, uri);

                intent.setType(StringSet.INTENT_TYPE);

                startActivity(intent);
                return true;
            case 2:
                intent=new Intent(getActivity(), MainActivity.class);
                intent.putExtra(StringSet.INTENT_PICTURE, ga.putname().get(contextPosition));
                startActivity(intent);
                return true;
        }

        return true;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("JHSS", "onactivityresult start");

        //GalleryActivity에서 그림이 저장될 경로를 가져옴
        GalleryActivity ga=new GalleryActivity();
        String path=ga.putDirPath();

        if(requestCode==REQ_CODE_SELECT_IMAGE){
            if(resultCode== Activity.RESULT_OK){
                try {
                    //album에서 선택한 특정한 이미지를 image_bitmap에 저장
                    Bitmap image_bitmap= MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), data.getData());
                    ImageForAlbum(image_bitmap, path, data.getData());
                } catch (FileNotFoundException e){
                    e.printStackTrace();
                } catch (IOException e){
                    e.printStackTrace();
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }

    /*
    http://kylblog.tistory.com/20
    http://blog.engintruder.com/48
     */

    //+버튼을 눌러 가져온 이미지를 내부저장소에 저장시킴
    public void ImageForAlbum(Bitmap bitmap, String dirPath, Uri data){
        Log.d("JHSS", "imageforalbum start");
        //////////////////////////////////////////////
        String[] proj={MediaStore.Images.Media.DATA};
        GalleryActivity ga=new GalleryActivity();
        Cursor cursor=getContext().getContentResolver().query(data, proj, null, null, null);
        int column_index=cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

        ArrayList<String> compareList=ga.putname();

        cursor.moveToFirst();

        //imgPath=갤러리를 이용해 이미지가 저장된 path를 가져옴
        String imgPath=cursor.getString(column_index);
        String imgName=imgPath.substring(imgPath.lastIndexOf("/")+1);

        String path=dirPath+"/"+imgName;
        ///////////////////////////////////////

        if(compareList.contains(imgName)){
            Toast.makeText(getContext(), getResources().getString(R.string.alreadyExist),
                    Toast.LENGTH_LONG).show();
        }
        else{
            //가져올 이미지의 대한 정보를 미리 알아와
            BitmapFactory.Options options=new BitmapFactory.Options();

            //해당 정보를 가지고 이미지의 메모리사용량을 줄이기 위한 코드
            options.inJustDecodeBounds=false;
            options.inSampleSize=4; //해당 숫자를 수정하면 메모리사용량이줄어듬 4<5<6<7....
            options.inPurgeable=true;

            //얻어온 이미지를 다시 decode해서 adapterview에 뿌려줄 Bitmap ArrayList에 저장
            Bitmap tmpbit=BitmapFactory.decodeFile(imgPath, options);
            ga.addBitmap(tmpbit, imgPath, imgName);
            try {
                //위에서 얻은 경로를 이용해 비트맵을 저장시킴
                FileOutputStream out = new FileOutputStream(path);

                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.close();
            } catch (FileNotFoundException e){
                e.printStackTrace();
            } catch (IOException e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        Log.d("JHSS", "framgelayout destroyed");
    }

    @Override
    public void onStart() {
        super.onStart();
        gridView.setAdapter(new ImageAdapter(getActivity(), GRIDVIEW));
        Log.d("JHSS", "framgelayout onstart");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d("JHSS", "framgelayout stop");
    }

}