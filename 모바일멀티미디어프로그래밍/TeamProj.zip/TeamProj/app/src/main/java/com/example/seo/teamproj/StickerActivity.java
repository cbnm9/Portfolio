package com.example.seo.teamproj;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.util.stream.IntStream;

public class StickerActivity extends AppCompatActivity {
    StickerPreview stickerPreview;  // 스티커 프리뷰 객체 (미리보기에 생성중인 스티커를 그려주는 커스텀 뷰)
    SeekBar sk; // 스티커 사이즈를 조정하는 시크바 뷰
    String dirPath = null; // 스티커 폴더 이름
    Button saveButton, cancelButton, photoButton;    // 저장,취소,사진 불러오기 버튼
    private final int PHOTO_IMAGE=7979; // 갤러리 사진 인텐트 실행 코드

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sticker);

        saveButton = findViewById(R.id.save_sticker_button);  // 저장 버튼
        cancelButton = findViewById(R.id.cancel_sticker_button);    // 취소 버튼
        stickerPreview = findViewById(R.id.sticker_preview_view);   // 스티커 프리뷰 객체
        photoButton = findViewById(R.id.photo_sticker_button);   // 이미지 갤러리 버튼

        sk = findViewById(R.id.sticker_size_seekBar); // 스티커 사이즈 조절 시크바 객체

        /* 시크바 체인지 리스너 등록 */
        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(stickerPreview.b != null) {
                    stickerPreview.DrawStickerSizeChange(progress); // 시크바의 값에 따라 스티커의 사이즈를 조절해서 그린다.
                    stickerPreview.setProgress(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        /* 저장 버튼 클릭 리스너 등록 */
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap = stickerPreview.getBitmap();

                if (dirPath == null){
                    dirPath= Environment.getExternalStorageDirectory()+"";
                    String picPath=StringSet.FIRST_DIR+"/"+
                                   StringSet.STICKER +"/";

                    File dir=new File(dirPath, picPath);
                    if(!dir.exists()){
                        dir.mkdirs();
                    }
                    dirPath=dirPath+"/"+picPath;
                }

                File dir = new File(dirPath);
                if (!dir.exists())
                    dir.mkdirs();

                // 유니크한 이름의 스티커를 찾을때까지 반복
                File toSave;
                String name;
                do{
                    name = StringSet.STICKER_NAME +
                           getRandomName(4) +
                           StringSet.STICKER_FILE_FORM;
                    toSave = new File(dirPath, name);
                } while (toSave.exists());

                // 스티커 저장하고 원래 액티비티에 파일 이름 보내준다.
                try {
                    FileOutputStream fOStream = new FileOutputStream(toSave);
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, fOStream);
                    fOStream.flush();
                    fOStream.close();

                    Intent resultIntent = new Intent();
                    resultIntent.putExtra(StringSet.INTENT_STICKER, name);
                    setResult(Activity.RESULT_OK, resultIntent);
                    finish();
                }catch (FileNotFoundException e){
                    Log.d("Exception", "onClick: Exception:" + e.toString());
                } catch(IOException e){
                    Log.d("Exception", "onClick: Exception:" + e.toString());
                }
            }
        });

        /* 취소 버튼 클릭 리스너 */
        // 취소 버튼
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        /* 사진 이미지 갤러리 버튼 리스너 */
        photoButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                goGallery();
            }

            // 인텐드로 갤러리 실행
            private void goGallery() {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.setType(StringSet.INTENT_TYPE);
                startActivityForResult(intent, PHOTO_IMAGE);
            }
        });
    }

    // 주어진 size만큼의 길이를 갖는 랜덤한 이름 생성
    // a-z,A-Z,0-9 까지의 문자로 이루어짐
    // 예시) size = 3  ->  a3D2
    // 리턴값은 생성된 이름
    private String getRandomName(int size){
        Random random = new Random();
        IntStream stream = random.ints(size, 0, 62);
        StringBuilder sb = new StringBuilder();
        for (int tmp : stream.toArray())
            if (tmp < 10) // 0-9
                sb.append((char)(tmp + '0'));
            else if (tmp < 10 + 26)  // a-z
                sb.append((char)('a' - 10 + tmp));
            else  // A-Z
                sb.append((char)('A' - 10 -26 + tmp));

        return sb.toString();
    }



    // 스티커 기본 모양 버튼을 누르면 실행됨
    public void StickerShapeBtnCliked(View button){
        stickerPreview.setProgress(sk.getProgress());
        switch(button.getId()){
            // 별
            case R.id.sticker_star_button:
                stickerPreview.DrawStar();
                break;
            // 하트
            case R.id.sticker_heart_button:
                stickerPreview.DrawHeart();
                break;
            // 뾰족한 십자모양
            case R.id.sticker_cross_button:
                stickerPreview.DrawCross();
                break;
            // 구름
            case R.id.sticker_cloud_button:
                stickerPreview.DrawCloud();
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if(requestCode == PHOTO_IMAGE)
        {
            if(resultCode==Activity.RESULT_OK)
            {
                try {
                    //이미지 데이터를 비트맵으로 받아온다.
                    Bitmap gallery_bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), data.getData());
                    gallery_bitmap = Bitmap.createScaledBitmap(gallery_bitmap, 230, 200, false);    // 브러쉬 미리보기 창에 맞도록 초기 사이즈를 조절한다
                    stickerPreview.b = gallery_bitmap;    // 스티커 프리뷰에 비트맵으로 설정

                    stickerPreview.DrawStickerSizeChange(sk.getProgress()); // 미리보기에 그린다
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


}