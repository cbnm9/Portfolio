package com.example.seo.teamproj;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

/*
갤러리에 사용될 ListView
 */
public class Gallery_ListViewFragment extends Fragment {
    View view;
    ListView list;
    int contextPosition;

    ArrayList<String> imgname=new ArrayList<String>();
    ArrayList<Bitmap> bitmaps=new ArrayList<Bitmap>();
    ArrayList<String> imgdate=new ArrayList<String>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //초기화 과정
        view=inflater.inflate(R.layout.fragment_galler__list_view, null);
        list=(ListView)view.findViewById(R.id.GalleryListView);

        //list에 context메뉴 생성
        registerForContextMenu(list);

        GalleryActivity ga=new GalleryActivity();
        imgname=ga.putname();
        bitmaps=ga.putbitmap();
        imgdate=ga.putImagedate();

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {

            }
        });
        return view;
    }

    //ImageAdapter와 다른 lsitView에서만 사용을 ListAdapter생성
    class ListAdapter extends ArrayAdapter<String> {
        private final Activity context;

        public int getCount(){
            return imgname.size();
        }

        public long getItemId(int index){
            return 0;
        }

        public ListAdapter(Activity context){
            super(context, R.layout.gallery_listitem, imgname);
            this.context=context;
        }

        //Listview로 내부저장소에서 가져온 그림의 정보 표시
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            LayoutInflater inflater=context.getLayoutInflater();
            View rowView=inflater.inflate(R.layout.gallery_listitem, null, true);
            ImageView imageView=(ImageView)rowView.findViewById(R.id.listviewimage);
            TextView title=(TextView)rowView.findViewById(R.id.listviewtitle);
            TextView date=(TextView)rowView.findViewById(R.id.listviewdate);

            title.setText(imgname.get(position));
            imageView.setImageBitmap(bitmaps.get(position));
            //date.setText(position+"");
            date.setText(imgdate.get(position));

            return rowView;


        }

    }

    //Context Menu 생성
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        if(v==list)
        {
            menu.setHeaderTitle(R.string.headerTitle);
            menu.add(0,1,0, R.string.gallery_menu_share);
            menu.add(0,2,0, R.string.gallery_menu_retouch);
            contextPosition=((AdapterView.AdapterContextMenuInfo)menuInfo).position;
        }
    }

    //Context Menu 세부 설정
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Intent intent=null;
        GalleryActivity ga=new GalleryActivity();

        switch (item.getItemId())
        {
            case 1:
                intent=new Intent(Intent.ACTION_SEND);

                String path=ga.putImagePath().get(contextPosition);
                Uri uri=Uri.parse(StringSet.URI_STR+path);
                intent.putExtra(StringSet.INTENT_SET_NAME,StringSet.INTENT_SET_VAL);
                intent.putExtra(Intent.EXTRA_STREAM, uri);

                intent.setType(StringSet.INTENT_TYPE);

                startActivity(intent);

                return true;
            case 2:
                intent=new Intent(getActivity(), MainActivity.class);
                intent.putExtra(StringSet.INTENT_PICTURE, ga.putname().get(contextPosition));
                startActivity(intent);
                return true;
        }
        return true;
    }

    public ListView getList() {
        return list;
    }

    @Override
    public void onStart() {
        super.onStart();
        list.setAdapter(new ListAdapter(getActivity()));
    }


}

