package com.example.seo.teamproj;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

/* 참고
http://jeongchul.tistory.com/287
*/

public class GalleryActivity extends AppCompatActivity {
    //그림에 관련된 정보들  bitmap, 이미지이름, 이미지날짜, 이미지경로
    public static ArrayList<Bitmap> bitmaps;
    public static ArrayList<String> imgname;
    public static ArrayList<String> imagedate;
    public static ArrayList<String> imagePath;
    public static String dirPath;
    SimpleDateFormat transtFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.KOREA);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("JHSS", "GalleryActivity oncreate");
        setContentView(R.layout.activity_gallery);

        //프래그먼트사용위한 초기화
        Gallery_GridViewFragment fragment=new Gallery_GridViewFragment();
        android.support.v4.app.FragmentTransaction fragmentTransaction=
                getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.fragment_container, fragment).commit();

        bitmaps=new ArrayList<Bitmap>();
        imgname=new ArrayList<String>();
        imagedate=new ArrayList<String>();
        imagePath=new ArrayList<String>();

        //경로설정
        PictureDirectory();
        //사진가져오기
        getImages();
    }

    //Actionbar에 optionmenu달기
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.galleryactionbarmenu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        android.support.v4.app.FragmentTransaction fragmentTransaction=
                getSupportFragmentManager().beginTransaction();

        switch (item.getItemId())
        {
            //ActionBar에서 버튼을 눌러야 표시
            case R.id.menu_nameuppersort:
                Toast.makeText(getApplicationContext(),
                       getResources().getString(R.string.nameUpperSort), Toast.LENGTH_SHORT).show();
                sort(imgname, imagedate);
                Log.d("JHSS", "이름오름차순");
                refreshAll();
                return true;
            case R.id.menu_namelowersort:
                Toast.makeText(getApplicationContext(),
                        getResources().getString(R.string.nameLowerSort),Toast.LENGTH_SHORT).show();
                reverseSort(imgname, imagedate);
                Log.d("JHSS", "이름내림차순");
                refreshAll();
                return true;
            case R.id.menu_dateuppersrt:
                Toast.makeText(getApplicationContext(),
                        getResources().getString(R.string.dateUpperSort),Toast.LENGTH_SHORT).show();
                sort(imagedate, imgname);
                Log.d("JHSS", "날짜오름차순");
                refreshAll();
                return true;
            case R.id.menu_datelowersort:
                Toast.makeText(getApplicationContext(),
                        getResources().getString(R.string.dateLowerSort),Toast.LENGTH_SHORT).show();
                reverseSort(imagedate, imgname);
                Log.d("JHSS", "날짜내림차순");
                refreshAll();
                return true;

            //ActionBar에 항상표시
            case R.id.menu_galleryView:
                fragmentTransaction.replace(R.id.fragment_container, new Gallery_GalleryViewFragment()).commit();
                return true;

            case R.id.menu_gridView:
                fragmentTransaction.replace(R.id.fragment_container,new Gallery_GridViewFragment()).commit();
                return true;

            case R.id.menu_listView:
                fragmentTransaction.replace(R.id.fragment_container, new Gallery_ListViewFragment()).commit();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //내부 그림 저장소의 경로
    public void PictureDirectory(){
        String dirPath=Environment.getExternalStorageDirectory()+"";
        String picPath=StringSet.FIRST_DIR+"/"+StringSet.PICTURE_DIR;

        File dir=new File(dirPath, picPath);
        if(!dir.exists()){
            dir.mkdirs();
        }
        dirPath=dirPath+"/"+picPath;
        this.dirPath=dirPath;
    }

    public void getImages(){
        String path=putDirPath();
        File file=new File(path);
        int imgCount;

        try {
            imgCount=file.listFiles().length;
        } catch (NullPointerException e){
            imgCount=0;
        }


        BitmapFactory.Options options=new BitmapFactory.Options();
        /*
        http://injunech.tistory.com/140
         */
             if(imgCount>0){
                for (File f : file.listFiles()) {
                    //파일이름을 가져와서 filestr에 저장
                    String filestr = f.getName();

                    //ArrayList에 파일이름 넣기
                    imgname.add(filestr);

                    options.inJustDecodeBounds = false;
                    options.inSampleSize = 4;
                    options.inPurgeable = true;

                    bitmaps.add(BitmapFactory.decodeFile(path + "/" + filestr, options));
                    imagePath.add(path + "/" + filestr);

                    File tmpfile = new File(path + "/" + filestr);

                    Date lastModdate = new Date(tmpfile.lastModified());
                    String imgdate = transtFormat.format(lastModdate);

                    imagedate.add(imgdate);
                }
            }
        Bitmap plus=BitmapFactory.decodeResource(getResources(), R.drawable.plus, options);
        bitmaps.add(plus);
        Log.d("JHSS", "getimage end");

    }

    public  ArrayList<Bitmap> putbitmap(){
        return bitmaps;
    }

    public  ArrayList<String> putname() {
        return imgname;
    }

    public ArrayList<String> putImagedate() {
        return imagedate;
    }

    public ArrayList<String> putImagePath() {
        return imagePath;
    }

    public void addBitmap(Bitmap bitmap, String path, String name){
        File tmpFile=new File(path);

        Date date=new Date(tmpFile.lastModified());
        String imgdate= transtFormat.format(date);
        bitmaps.add(bitmaps.size()-1, bitmap);
        imgname.add(imgname.size(),name);
        imagedate.add(imagedate.size(), imgdate);
        //imagePath.add(imagePath.size(), path);
        imagePath.add(imagePath.size(), dirPath+"/"+imgname);

        Log.d("JHSS", "addBitmap end");
    }

    public String putDirPath(){
        return dirPath;
    }

    public void sort(ArrayList<String> mainsort, ArrayList<String> subsort2){
        Bitmap tmpbitmap=bitmaps.get(bitmaps.size()-1);
        bitmaps.remove(bitmaps.size()-1);
        Log.d("JHSS", "sort start");

        for(int i=0;i<mainsort.size();i++){
            for(int j=1; j<mainsort.size();j++){
                int cmp=mainsort.get(j-1).compareTo(mainsort.get(j));
                if(cmp>0){
                    String tmp=mainsort.get(j-1);
                    mainsort.set(j-1, mainsort.get(j));
                    mainsort.set(j, tmp);

                    Bitmap bitmap=bitmaps.get(j-1);
                    bitmaps.set(j-1, bitmaps.get(j));
                    bitmaps.set(j, bitmap);

                    tmp=subsort2.get(j-1);
                    subsort2.set(j-1, subsort2.get(j));
                    subsort2.set(j, tmp);

                    tmp=imagePath.get(j-1);
                    imagePath.set(j-1, imagePath.get(j));
                    imagePath.set(j, tmp);
                }
            }
        }

        bitmaps.add(tmpbitmap);

    }

    public void reverseSort(ArrayList<String> mainsort, ArrayList<String> subsort2){
        Log.d("JHSS", "reversesort start");
        sort(mainsort, subsort2);

        Bitmap bitmap=bitmaps.get(bitmaps.size()-1);
        bitmaps.remove(bitmaps.size()-1);

        Collections.reverse(bitmaps);
        bitmaps.add(bitmap);
        Collections.reverse(imagedate);
        Collections.reverse(imgname);
        Collections.reverse(imagePath);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("JHSS", "onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("JHSS", "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("JHSS", "onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("JHSS", "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        bitmaps=null;
        imgname=null;
        imagedate=null;
        imagePath=null;

        Log.d("JHSS", "onDestroy");
    }

    public void refreshAll(){
        for(Fragment fragment: getSupportFragmentManager().getFragments()){
            if(fragment.isVisible()){
                fragment.onStart();
            }
        }
    }
}
