package com.example.seo.teamproj;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.Image;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.File;
import java.util.ArrayList;

/*
gridview, adapterview listview만들때 사용
 */
public class ImageAdapter extends BaseAdapter {
    public static final int GRIDVIEW=0;
    public static final int GALLERYVIEW=1;

    private Context mContext;
    public int currentView;

    public ArrayList<Bitmap> bitmaps;

    public ImageAdapter(){
    }

    public ImageAdapter(Context c, int view){
        mContext=c;
        currentView=view;
        GalleryActivity ga=new GalleryActivity();
        bitmaps=ga.putbitmap();
    }

    /*
     http://berabue.tistory.com/18
     특정폴더에 있는 이미지불러오기
     */
    public int getCount(){
        return bitmaps.size();
    }

    public Object getItem(int index){
        return null;
    }

    public long getItemId(int index){
        return 0;
    }

    /*
    https://kimdohyeong.gitbooks.io/android_official_training_kr/content/Displaying_BItmaps_in_your_UI.html
     */
    //adapter를 이용 gridview와 galleryview일때 출력되는 결과를 다르게 표시
    public View getView(int position, View convertView, ViewGroup parent){
        ImageView imageView=null;

        if(convertView==null){
            imageView=new ImageView(mContext);
            switch (currentView)
            {
                case GRIDVIEW:
                    imageView.setLayoutParams(new  GridView.LayoutParams(350,350));
                    imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    imageView.setPadding(8,8,8,8);
                    Log.d("JHSS ", "GRIDVIEW ADAPTER");
                    break;
                case GALLERYVIEW:
                    imageView.setLayoutParams(new Gallery.LayoutParams(400, 400));
                    imageView.setImageBitmap(bitmaps.get(position));
                    imageView.setBackgroundColor(Color.GRAY);
                    Log.d("JHSS ", "GALLERYVIEW ADAPTER");
                    break;
            }

        }
        else
        {
            imageView=(ImageView)convertView;
        }

        imageView.setImageBitmap(bitmaps.get(position));
        return imageView;
    }
}