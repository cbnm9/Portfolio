package com.example.seo.teamproj;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

// StickerPreview는 현재 생성중인 스티커를 미리 볼 수 있는 커스텀 뷰 클래스입니다.
public class StickerPreview extends View {
    public Bitmap b = null;    // 미리보기에 그릴 스티커 모양 비트맵 원본
    Bitmap db = null;   // 미리보기에 실제 그릴 비트맵
    Bitmap return_bitmap; // ok 버튼 누르면 리턴되는 비트맵
    Canvas saveCanvas = null; // return_bitmap 그리는 Canvas
    int p;  // 시크바의 현재 값

    // 생성자
    public StickerPreview(Context context) {
        super(context);
    }

    public StickerPreview(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public StickerPreview(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // 처음 호출시 초기화
        if (saveCanvas == null){
            return_bitmap = Bitmap.createBitmap(this.getWidth(), this.getHeight(), Bitmap.Config.ARGB_8888);
            saveCanvas = new Canvas(return_bitmap);
        }

        // 미리보기에 그릴 스티커 모양 비트맵이 정해진 경우 커스텀 뷰에 그린다.
        if(db != null) {
            // 캔버스의 가운데에 스티커 모양을 그린다
            canvas.drawBitmap(db, this.getWidth()/2 - db.getWidth()/2, this.getHeight()/2 - db.getHeight()/2, null);

            // 리턴되는 비트맵 그리기
            return_bitmap.eraseColor(Color.TRANSPARENT);
            saveCanvas.drawBitmap(db, this.getWidth()/2 - db.getWidth()/2, this.getHeight()/2 - db.getHeight()/2, null);
        }
    }

    // 별 스티커 모양 그리기
    public void DrawStar(){
        b = BitmapFactory.decodeResource(getResources(), R.drawable.star);
        db = b;
        DrawStickerSizeChange(p);
    }

    // 하트 스티커 모양 그리기
    public void DrawHeart(){
        b = BitmapFactory.decodeResource(getResources(), R.drawable.heart);
        db = b;
        DrawStickerSizeChange(p);
    }

    // 십자 스티커 모양 그리기
    public void DrawCross(){
        b = BitmapFactory.decodeResource(getResources(), R.drawable.cross);
        db = b;
        DrawStickerSizeChange(p);
    }

    // 구름 스티커 모양 그리기
    public void DrawCloud(){
        b = BitmapFactory.decodeResource(getResources(), R.drawable.cloud);
        db = b;
        DrawStickerSizeChange(p);
    }

    // 스티커 크기가 변경됨에 따라 사이즈를 조절해서 모양 그리기
    public void DrawStickerSizeChange(int size){
        db = Bitmap.createScaledBitmap(b, b.getWidth()+size, b.getHeight()+size, false);
        invalidate();
    }

    // 스티커 액티비티에서 호출하는 용. 시크바의 현재 값을 저장.
    public void setProgress(int p){
        this.p = p;
    }

    // 스티커 액티비티에서 호출하는 용. 현재 설정되어있는 비트맵을 복사하여 준다.
    public Bitmap getBitmap(){
        return Bitmap.createBitmap(return_bitmap);
    }
}
