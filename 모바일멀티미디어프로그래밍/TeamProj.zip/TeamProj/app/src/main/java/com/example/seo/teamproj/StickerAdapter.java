package com.example.seo.teamproj;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import java.io.File;
import java.util.ArrayList;

public class StickerAdapter extends RecyclerView.Adapter<StickerAdapter.ViewHolder> {
    // 그림 데이터들
    private ArrayList<StickerData> mData;
    private Context mContext;
    private String parentDir;
    private Drawing mDrawing;
    private boolean mFirstTime = true;
    private int mUndeleteLimit;
    private int mSelectedIndex = -1;

    // 모든 뷰가 같은 사이즈를 공유하므로
    private static Integer pixel_length = null;

    public static class ViewHolder extends RecyclerView.ViewHolder{
        public ImageButton mImageButton;

        // RecycerView에 사용할 ViewHolder
        public ViewHolder(ImageButton view){
            super(view);
            mImageButton = view;
        }
    }

    public StickerAdapter(ArrayList<String> names, Context context, int unDeleteLimit){
        mContext = context;
        mUndeleteLimit = unDeleteLimit;

        String dirPath= Environment.getExternalStorageDirectory()+"";
        String picPath=StringSet.FIRST_DIR+"/"+
                       StringSet.STICKER +"/";

        File dir=new File(dirPath, picPath);
        if(!dir.exists()){
            dir.mkdirs();
        }
        parentDir=dirPath+"/"+picPath;

        // 주어진 이름으로 스티커 데이타 초기화
        mData = new ArrayList<StickerData>();
        for (String name : names)
            mData.add(new StickerData(name));
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ImageButton imageButton = new ImageButton(parent.getContext(), null, R.style.myBrushImageButton);

        if (pixel_length == null){
            pixel_length = (int) parent.getResources().getDimension(R.dimen.menu_size);
        }

        imageButton.setLayoutParams(new ViewGroup.LayoutParams(pixel_length, pixel_length));

        return new ViewHolder(imageButton);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        final StickerData data = mData.get(position);

        // 비트맵이 없으면 스레드로 가져오기
        if (!data.isBitmapSet()) {
            Thread thread = new Thread() {
                @Override
                public void run() {
                    Bitmap toDraw = BitmapFactory.decodeFile(parentDir+data.getName());
                    data.setBitmap(toDraw);

                    final Drawable drawable = new BitmapDrawable(mContext.getResources(), toDraw);
                    ((Activity) mContext).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            holder.mImageButton.setImageDrawable(drawable);
                        }
                    });

                    bindImageButton(position, holder, data.getBitmap());
                }
            };

            thread.start();
        }
        else{ // 이미 있으면 그냥 사용
            final Drawable drawable = new BitmapDrawable(mContext.getResources(), data.getBitmap());
            ((Activity) mContext).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    holder.mImageButton.setImageDrawable(drawable);
                }
            });
            bindImageButton(position, holder, data.getBitmap());
        }
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    void bindImageButton(final int position, ViewHolder holder, final Bitmap bm){
        holder.mImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawing.setStickerBitmap(bm);
                mSelectedIndex = position;
            }
        });

        if (position >= mUndeleteLimit)
            holder.mImageButton.setOnCreateContextMenuListener(new View.OnCreateContextMenuListener() {
                @Override
                public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
                    menu.add(0, 1, position, R.string.Sticker_menu_delete);
                }
            });
        else{
            holder.mImageButton.setBackgroundColor(Color.parseColor("#33ff0000"));
        }

        if (position == 0 && mFirstTime) {
            mFirstTime = false;
            mDrawing.setStickerBitmap(bm);
        }
    }

    // 새로운 스티커 데이터 추가
    public void pushBackData(String name){
        final StickerData toAdd = new StickerData(name);
        mData.add(toAdd);
        mSelectedIndex = mData.size()-1;
        notifyItemInserted(mData.size()-1);

        if (toAdd.isBitmapSet())
            mDrawing.setStickerBitmap(toAdd.getBitmap());
        else {
            Thread thread = new Thread() {
                @Override
                public void run() {
                    Bitmap toDraw = BitmapFactory.decodeFile(parentDir + toAdd.getName());
                    toAdd.setBitmap(toDraw);

                    mDrawing.setStickerBitmap(toAdd.getBitmap());
                }
            };

            thread.start();
        }
    }

    public void setDrawing(Drawing drawing){
        mDrawing = drawing;
    }

    // 해당 position 스티커 데이터 삭제
    public void deleteData(int position){
        String dirPath= Environment.getExternalStorageDirectory()+"";
        String picPath=StringSet.FIRST_DIR+"/"+
                       StringSet.STICKER +"/";

        File dir=new File(dirPath, picPath);
        if(!dir.exists()){
            dir.mkdirs();
        }
        dirPath=dirPath+"/"+picPath;

        dir = new File(dirPath, mData.get(position).getName());
        dir.delete();

        mData.remove(position);
        if (mSelectedIndex == position){
            mDrawing.setStickerBitmap(null);
        }else if (mSelectedIndex > position)
            mSelectedIndex--;

        notifyItemRemoved(position);
        notifyItemRangeChanged(position, mData.size()-position);
    }

    public ArrayList<StickerData> getData(){
        return mData;
    }
}
