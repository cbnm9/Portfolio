package com.example.seo.teamproj;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.LinkedList;

public class Drawing extends View {

    //그리기모드를 정의한 상수
    static final int FREE_LINE=0; //자유선
    static final int LINE=1; //선
    static final int RECT=2; //네모
    static final int STICKER =3;//스티커
    static final int ELLI=4; //원
    static final int TRI=5;  //삼각형
    static final int TEXT=6; //텍스트
    static final int ERASER=7;//지우개

    //메인 액티비티의 메소드 호출을 위한 컨텍스트
    private Context mContext;

    //불러온 그림이 수정 되었는지
    private boolean change_state;
    private int saved_point;

    //비트맵 객체들을 저장할 연결리스트와 그 정보
    private LinkedList btm_list;
    private int index;      //저장된 비트맵 갯수
    private int btm_point;  //현재 가리키는 위치(Undo, Redo)

    //브러시로 사용될 비트맵
    private Bitmap stickerOriginal; //스티커로 쓸 비트맵 원본
    private Bitmap stickerBitmap;   //크기 조정후 실제로 그릴 비트맵

    //화면에 그릴 그림의 비트맵과 캔버스
    private Bitmap canvasBitmap;
    private Canvas finCanvas;

    //베이스 비트맵(최하위 비트맵)과 캔버스
    private Bitmap baseBitmap;
    private Canvas baseCanvas;

    //리스트 추가용 임시 비트맵과 캔버스
    private Bitmap temp_bitmap;
    private Canvas drawCanvas;

    //Canvas 용 Paint
    private Paint canvasPaint;

    //그릴 그림의 Paint
    private Paint paint_freeLine;//자유선
    private Paint paint_line;    //직선
    private Paint paint_diagram; //도형(네모, 원, 세모)
    private Paint paint_pre;//도형 그리기 전 윤곽선
    private Paint paint_text;//텍스트
    private Paint paint_eraser;//지우개
    private Paint paint_sticker;//스티커

    //그리기용 쓰레드와 변수들(자유선, 지우개)
    private DrawThread drawThread;
    private boolean running;
    private float dist;
    private PathMeasure pathMeasure;

    //선과 지우개용 크기정보
    private float size_freeLine;
    private float size_eraser;

    //스티커용 크기
    private int stickerSize;

    //도형 그리기용 Path
    private Path path;

    //조건분기를 위한 변수들
    private boolean condition;//Action Down/Up
    private int drawMode;//그리기모드
    private boolean preAdd; //도형이 리스트에 추가되기전/후
    private boolean ready=true;  //비트맵을 그릴 준비가 되었는지(initializeBitmap 을 위한변수)

    //화면의 크기
    private int width, height;

    //도형 그리기용 좌표저장변수
    private float start_X;
    private float start_Y;

    //텍스트 그리기용 String 객체 및 좌표저장변수
    private String text;
    private float text_X;
    private float text_Y;

    //생성자들
    public Drawing(Context context) {
        super(context);
        initialize();
        mContext=context;
    }
    public Drawing(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize();
        mContext=context;
    }
    public Drawing(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initialize();
        mContext=context;
    }

    //초기화 메소드
    private void initialize() {
        //수정여부 변수 초기화
        change_state=false;
        saved_point=0;

        //선, 삼각형 그리기용 패스
        path = new Path();

        //비트맵 리스트
        btm_list = new LinkedList();
        index = 0;
        btm_point = 0;

        //조건문 변수
        condition = false;
        drawMode=FREE_LINE;
        preAdd=false;

        //캔버스용 페인트
        canvasPaint = new Paint(Paint.DITHER_FLAG);

        //선그리기용 페인트
        paint_line = new Paint();
        paint_line.setAntiAlias(true);
        paint_line.setStyle(Paint.Style.STROKE);
        paint_line.setStrokeJoin(Paint.Join.ROUND);

        paint_line.setColor(Color.BLACK);
        paint_line.setStrokeWidth(10f);

        //도형 그리기용 페인트
        paint_diagram=new Paint();
        paint_diagram.setAntiAlias(true);
        paint_diagram.setStyle(Paint.Style.FILL_AND_STROKE);
        paint_diagram.setColor(Color.BLACK);

        //도형 그리기 전 윤곽선
        paint_pre=new Paint();
        paint_pre.setAntiAlias(true);
        paint_pre.setStyle(Paint.Style.STROKE);
        paint_pre.setColor(Color.GRAY);

        //텍스트 그리기용 페인트
        paint_text=new Paint();

        paint_text.setColor(Color.BLACK);
        paint_text.setTextSize(30);

        //지우개용 페인트
        paint_eraser=new Paint();
        paint_eraser.setAntiAlias(true);
        paint_eraser.setStyle(Paint.Style.FILL);
        paint_eraser.setColor(Color.WHITE);

        size_eraser=20f;

        //자유선용 페인트
        paint_freeLine=new Paint();
        paint_freeLine.setAntiAlias(true);
        paint_freeLine.setStyle(Paint.Style.FILL);

        paint_freeLine.setColor(Color.BLACK);
        size_freeLine=5f;

        //스티커용 변수
        stickerSize =50;
        paint_sticker =new Paint();
        paint_sticker.setAntiAlias(true);
        running=true;

        //임시 스티커 그리기 테스트용
        setStickerBitmap(null);
    }

    //비트맵초기화(초기화면)
    public void initializeBitmap(final Bitmap btm) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(ready);
                baseCanvas.drawBitmap(btm, 0, 0, canvasPaint);
                finCanvas.drawBitmap(baseBitmap, 0, 0, canvasPaint);
                change_state=false;
            }
        }).start();
    }

    //저장시 현재화면 모두 합친 비트맵 넘겨주기
    public Bitmap getBitmapForSave() {
        sumBtm();
        saved_point=btm_point;
        change_state=false;
        return canvasBitmap;
    }

    //비트맵이 수정되었는지 여부 반환
    public boolean isChanged() {
        if(!change_state) {
            if(saved_point!=btm_point)
                return true;
        }
        return change_state;
    }

    //메인화면에서 새 파일 만들기 했을시 Drawing 초기화 하기
    public void newDrawing() {
        //수정여부 변수 초기화
        change_state=false;
        saved_point=0;

        //비트맵 리스트
        btm_list = new LinkedList();
        index = 0;
        btm_point = 0;

        //그림판 하얗게 초기화
        finCanvas.drawColor(Color.WHITE);
        baseCanvas.drawColor(Color.WHITE);
        invalidate();
    }

    //수정하기 선택시 해당 그림 가져오기
    public void setRetouchBitmap(Bitmap btm) {
        baseCanvas.drawBitmap(btm, 0, 0, canvasPaint);
        finCanvas.drawBitmap(btm, 0, 0, canvasPaint);
        invalidate();
    }

    //Undo, Redo 기능
    public void undo() {
        if(running) {
            if(btm_point>0) {
                btm_point--;
            }
            sumBtm();
            invalidate();
        }
    }
    public boolean stateUndo() {
        if(btm_point>0)
            return true;
        else
            return false;
    }
    public void redo() {
        if(running) {
            if(btm_point<index)
                btm_point++;
            sumBtm();
            invalidate();
        }
    }
    public boolean stateRedo() {
        if(btm_point<index)
            return true;
        else
            return false;
    }

    //선그리기, 도형그리기 등 모드전환 기능
    public void setMode(int mode) {
        drawMode=mode;
    }

    //페인트 변경 메소드-MainActivity 에서 호출
    //1. 크기변경
    public void setPaintSize(float size) {
        switch(drawMode) {
            case FREE_LINE:
                size_freeLine=size/2;
                break;
            case LINE:
                paint_line.setStrokeWidth(size);
                break;
            case TEXT:
                paint_text.setTextSize(size);
                break;
            case STICKER:
                stickerSize =(int)size;
                setStickerSize();
                break;
            case ERASER:
                size_eraser=size/2;
                break;
        }
    }
    //2. 색상변경
    public void setPaintColor(int color) {
        paint_freeLine.setColor(color);
        paint_line.setColor(color);
        paint_diagram.setColor(color);
        paint_text.setColor(color);
    }

    //현재 페인트의 크기 정보 넘겨주는 함수
    public float sizeOfPaint(int what) {
        switch (what) {
            case FREE_LINE:
                return size_freeLine*2;
            case LINE:
                return paint_line.getStrokeWidth();
            case TEXT:
                return paint_text.getTextSize();
            case STICKER:
                return stickerSize;
            case ERASER:
                return size_eraser*2;
            default:
                return -1;
        }
    }

    //스티커 사용시 사용할 비트맵 가져오기 (MainActivity 에서 호출)
    public void setStickerBitmap(Bitmap bm) {
        // 지정된 스티커 없으면 무시
        if (bm == null)
            return;

        stickerOriginal =Bitmap.createBitmap(bm);

        setStickerSize();
    }

    //스티커 반환
    public Bitmap getStickerBitmap(){
        return stickerOriginal;
    }

    //스티커 크기 변경
    private void setStickerSize() {
        stickerBitmap =Bitmap.createScaledBitmap(stickerOriginal, stickerSize, stickerSize, true);
    }

    //화면에 그릴 비트맵들 하나로 합치기
    private void sumBtm() {
        finCanvas.drawColor(Color.WHITE);
        finCanvas.drawBitmap(baseBitmap, 0, 0, canvasPaint);

        if(btm_point!=0) {
            for(int i=0; i<btm_point; i++) {
                finCanvas.drawBitmap((Bitmap)btm_list.get(i), 0, 0, canvasPaint);
            }
        }
    }

    //비트맵 객체를 리스트에 추가하기
    private void addBtm() {
        temp_bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        drawCanvas = new Canvas(temp_bitmap);

        //addBtm 은 TEXT, LINE, 도형 그릴때만 호출됨
        if(drawMode==TEXT)
            drawCanvas.drawText(text, text_X, text_Y, paint_text);
        else if(drawMode==LINE)
            drawCanvas.drawPath(path, paint_line);
        else
            drawCanvas.drawPath(path, paint_diagram);

        pushList(temp_bitmap);
    }

    //addBtm 에서만 호출하는 리스트에 비트맵 삽입 함수
    private void pushList(Bitmap temp_bitmap) {
        //만약 추가하는시점이 Undo 를 한 시점이라면
        if(index!=btm_point) {
            //btm_point 위의 비트맵들을 삭제한다
            int k=btm_point;
            while(k<index) {
                btm_list.removeLast();
                k++;
            }
            index=btm_point;
        }
        btm_list.add(temp_bitmap);
        index++;
        //만약 스택이 10개 넘게 쌓였다면
        if(index>10) {
            //최하위 하나를 베이스에 합친다
            baseCanvas.drawBitmap((Bitmap)btm_list.pollFirst(), 0, 0, canvasPaint);
            index--;
            change_state=true;
            saved_point=0;
        }
        btm_point=index;
    }

    //그리기 모드별 터치이벤트 동작
    //0. 자유선 그리기
    private boolean modeFreeLine(MotionEvent event) {
        if(!running)
            return false;

        //터치 발생한 좌표 가져오기
        float touchX = event.getX();
        float touchY = event.getY();

        //이벤트에 따른 처리
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.reset();
                dist=0f;
                path.moveTo(touchX, touchY);

                temp_bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                drawCanvas = new Canvas(temp_bitmap);

                drawThread =new DrawThread();
                drawThread.start();
                break;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(touchX, touchY);
                break;
            case MotionEvent.ACTION_UP:
                running=false;
                break;
            default:
                return false;
        }
        return true;
    }
    //1. 선 그리기
    private boolean modeLine(MotionEvent event) {
        //터치 발생한 좌표 가져오기
        float touchX = event.getX();
        float touchY = event.getY();

        //이벤트에 따른 처리
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.reset();
                start_X=touchX;
                start_Y=touchY;
                preAdd=true;
                break;
            case MotionEvent.ACTION_MOVE:
                path.reset();
                if(!(touchX==start_X && touchY==start_Y)) {
                    path.moveTo(start_X, start_Y);
                    path.lineTo(touchX, touchY);
                }
                break;
            case MotionEvent.ACTION_UP:
                if(!(touchX==start_X && touchY==start_Y)) {
                    finCanvas.drawPath(path, paint_line);
                    condition=true;
                }
                preAdd=false;
                break;
            default:
                return false;
        }
        return true;
    }
    //2. 스티커 그리기-done
    private boolean modeSticker(MotionEvent event) {
        //터치 발생한 좌표 가져오기(비트맵을 그 좌표 중심에 그려야됨)
        float touchX = event.getX()- stickerBitmap.getWidth()/2;
        float touchY = event.getY()- stickerBitmap.getHeight()/2;

        //이벤트에 따른 처리
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                preAdd=true;

                temp_bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                drawCanvas = new Canvas(temp_bitmap);

                drawCanvas.drawBitmap(stickerBitmap, touchX, touchY, paint_sticker);
                break;
            case MotionEvent.ACTION_MOVE:
                drawCanvas.drawBitmap(canvasBitmap, 0, 0, canvasPaint);
                drawCanvas.drawBitmap(stickerBitmap, touchX, touchY, paint_sticker);
                break;
            case MotionEvent.ACTION_UP:
                finCanvas.drawBitmap(stickerBitmap, touchX, touchY, paint_sticker);
                pushList(temp_bitmap);
                preAdd=false;
                break;
            default:
                return false;
        }
        return true;
    }
    //3. 타원 그리기-done
    private boolean modeElli(MotionEvent event) {
        //터치 발생한 좌표 가져오기
        float touchX = event.getX();
        float touchY = event.getY();
        float X1, X2, Y1, Y2;

        //이벤트에 따른 처리
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.reset();
                start_X=touchX;
                start_Y=touchY;
                preAdd=true;
                break;
            case MotionEvent.ACTION_MOVE:
                path.reset();
                if(touchX<start_X) {
                    X1=touchX; X2=start_X;
                } else {
                    X1=start_X; X2=touchX;
                }

                if(touchY<start_Y) {
                    Y1=touchY; Y2=start_Y;
                } else {
                    Y1=start_Y; Y2=touchY;
                }

                if(!((touchX==start_X) || (touchY==start_Y))) {
                    path.addOval(X1, Y1, X2, Y2, Path.Direction.CW);
                }
                break;
            case MotionEvent.ACTION_UP:
                if(!((touchX==start_X) || (touchY==start_Y))) {
                    finCanvas.drawPath(path, paint_diagram);
                    condition = true;
                }
                preAdd=false;
                break;
            default:
                return false;
        }
        return true;
    }
    //4. 삼각형 그리기-done
    private boolean modeTri(MotionEvent event) {
        //터치 발생한 좌표 가져오기
        float touchX = event.getX();
        float touchY = event.getY();
        float X1, X2, Y1, Y2;

        //이벤트에 따른 처리
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.reset();
                start_X=touchX;
                start_Y=touchY;
                preAdd=true;
                break;
            case MotionEvent.ACTION_MOVE:
                path.reset();
                if(touchX<start_X) {
                    X1=touchX; X2=start_X;
                } else {
                    X1=start_X; X2=touchX;
                }

                if(touchY<start_Y) {
                    Y1=touchY; Y2=start_Y;
                } else {
                    Y1=start_Y; Y2=touchY;
                }

                if(!((touchX==start_X) || (touchY==start_Y))) {
                    path.moveTo(X1, Y2);
                    path.lineTo(X2, Y2);
                    path.lineTo((X1+X2)/2, Y1);
                    path.close();
                }
                break;
            case MotionEvent.ACTION_UP:
                if(!((touchX==start_X) || (touchY==start_Y))) {
                    finCanvas.drawPath(path, paint_diagram);
                    condition = true;
                }
                preAdd=false;
                break;
            default:
                return false;
        }
        return true;
    }
    //5. 네모 그리기-done
    private boolean modeRect(MotionEvent event) {
        //터치 발생한 좌표 가져오기
        float touchX = event.getX();
        float touchY = event.getY();

        float X1, X2, Y1 ,Y2;

        //이벤트에 따른 처리
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.reset();
                start_X=touchX;
                start_Y=touchY;
                preAdd=true;
                break;
            case MotionEvent.ACTION_MOVE:
                path.reset();
                if(touchX<start_X) {
                    X1=touchX; X2=start_X;
                } else {
                    X1=start_X; X2=touchX;
                }

                if(touchY<start_Y) {
                    Y1=touchY; Y2=start_Y;
                } else {
                    Y1=start_Y; Y2=touchY;
                }

                if(!((touchX==start_X) || (touchY==start_Y))) {
                    path.addRect(X1, Y1, X2, Y2, Path.Direction.CW);
                }
                break;
            case MotionEvent.ACTION_UP:
                if(!((touchX==start_X) || (touchY==start_Y))) {
                    finCanvas.drawPath(path, paint_diagram);
                    condition = true;
                }
                preAdd=false;
                break;
            default:
                return false;
        }
        return true;
    }
    //6. 글자 그리기-done
    private boolean modeText(MotionEvent event) {
        //터치 발생한 좌표 가져오기
        text_X = event.getX();
        text_Y = event.getY();

        //이벤트에 따른 처리
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_UP:
                text="";
                drawTextDialog();
                break;
            default:
                return false;
        }
        return true;
    }
    //7. 지우개-done
    private boolean modeEraser(MotionEvent event) {
        if(!running)
            return false;

        //터치 발생한 좌표 가져오기
        float touchX = event.getX();
        float touchY = event.getY();

        //이벤트에 따른 처리
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.reset();
                dist=0f;
                path.moveTo(touchX, touchY);

                temp_bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                drawCanvas = new Canvas(temp_bitmap);

                drawThread =new DrawThread();
                drawThread.start();
                break;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(touchX, touchY);
                break;
            case MotionEvent.ACTION_UP:
                running=false;
                break;
            default:
                return false;
        }
        return true;
    }

    //문자열 입력받아 화면에 그리는 다이얼로그
    private void drawTextDialog() {
        final Dialog dialog=new Dialog(mContext);
        dialog.setContentView(R.layout.drawtextdialog);
        dialog.setCancelable(false);

        ((Button) dialog.findViewById(R.id.OK_button_drawTextDialog)).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                text=((EditText) dialog.findViewById(R.id.edit_drawTextDialog)).getText().toString();

                if(!(text.isEmpty())) {
                    finCanvas.drawText(text, text_X, text_Y, paint_text);
                    invalidate();
                    addBtm();
                }

                dialog.dismiss();
            }
        });

        ((Button) dialog.findViewById(R.id.NO_button_drawTextDialog)).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    //뷰의 크기가 변했을때
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        //화면에 그릴 그림용 비트맵 생성
        canvasBitmap=Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        finCanvas=new Canvas(canvasBitmap);
        baseBitmap=Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        baseCanvas=new Canvas(baseBitmap);
        width=w;
        height=h;
        ready=false;
    }

    //화면에 그리기
    @Override
    protected void onDraw(Canvas canvas) {
        //화면에 그리기
        canvas.drawBitmap(canvasBitmap, 0, 0, canvasPaint);

        //도형의경우 리스트에 추가되기 전에 해야할 동작
        if(preAdd) {
            switch (drawMode) {
                case LINE:
                    canvas.drawPath(path, paint_line);
                    break;
                case STICKER:
                    canvas.drawBitmap(temp_bitmap, 0, 0, canvasPaint);
                    break;
                default:
                    canvas.drawPath(path, paint_pre);
                    break;
            }
        }

        //메인 엑티비티의 Undo, Redo 버튼 제어
        ((MainActivity) mContext).doStateUpdate();
    }

    //터치 이벤트 처리
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean state=true;

        //그리기 모드별 터치이벤트 처리
        switch (drawMode) {
            case FREE_LINE:
                state=modeFreeLine(event);
                break;
            case LINE:
                state=modeLine(event);
                break;
            case RECT:
                state=modeRect(event);
                break;
            case ELLI:
                state=modeElli(event);
                break;
            case TRI:
                state=modeTri(event);
                break;
            case TEXT:
                state=modeText(event);
                break;
            case ERASER:
                state=modeEraser(event);
                break;
            case STICKER:
                state= modeSticker(event);
                break;
        }

        //터치이벤트중 default 일때 false 반환
        if(state==false) {
            return false;
        }

        //화면 그리기(onDraw 호출)
        invalidate();

        //그린 비트맵을 리스트에 추가하기
        if (condition) {
            addBtm();
            condition=false;
        }

        return true;
    }

    //스레드
    public class DrawThread extends Thread {
        public void run() {
            float pos[] = new float[2];

            while(running) {
                pathMeasure=new PathMeasure(path, false);
                while(dist<pathMeasure.getLength()) {
                    pathMeasure.getPosTan(dist, pos, null);
                    switch (drawMode) {
                        case FREE_LINE:
                            finCanvas.drawOval(pos[0]-size_freeLine, pos[1]-size_freeLine,
                                    pos[0]+size_freeLine, pos[1]+size_freeLine, paint_freeLine);
                            drawCanvas.drawOval(pos[0]-size_freeLine, pos[1]-size_freeLine,
                                    pos[0]+size_freeLine, pos[1]+size_freeLine, paint_freeLine);
                            break;
                        case ERASER:
                            finCanvas.drawOval(pos[0]-size_eraser, pos[1]-size_eraser,
                                    pos[0]+size_eraser, pos[1]+size_eraser, paint_eraser);
                            drawCanvas.drawOval(pos[0]-size_eraser, pos[1]-size_eraser,
                                    pos[0]+size_eraser, pos[1]+size_eraser, paint_eraser);
                            break;
                    }

                    dist+=5;
                }
            }
            pushList(temp_bitmap);
            running=true;
            path.reset();
        }

    }

}
