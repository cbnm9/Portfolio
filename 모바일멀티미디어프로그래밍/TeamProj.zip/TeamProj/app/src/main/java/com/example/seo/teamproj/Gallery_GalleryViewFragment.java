package com.example.seo.teamproj;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/*
갤러리에 사용될 GalleryViewFragment
 */

public class Gallery_GalleryViewFragment extends Fragment {
    public static final int GALLERYVIEW=1;
    final int REQ_CODE_SELECT_IMAGE=10;

    View view;
    Gallery gallery;
    ImageView imageView;
    Intent albumIntent=null;
    int contextPosition;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //초기화 과정
        final GalleryActivity ga=new GalleryActivity();
        view=inflater.inflate(R.layout.fragment_gallery__gallery_view, null);
        gallery=(Gallery)view.findViewById(R.id.Gallery);
        imageView=(ImageView)view.findViewById(R.id.GalleryImageView);
        //imageview를 0번째 비트맵으로 초기화
        imageView.setImageBitmap(ga.putbitmap().get(0));

        albumIntent=new Intent(Intent.ACTION_PICK);
        albumIntent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        albumIntent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        //imageview와 gallery에 contextmenu달기
        registerForContextMenu(imageView);
        registerForContextMenu(gallery);

        gallery.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View v, int position, long id) {
                //길게 눌렀을때 '+'인 경우 contextmenu를 생성하지 않음
                if(adapterView.getCount()==(position+1)){
                    unregisterForContextMenu(gallery);
                }
                else{
                    registerForContextMenu(gallery);
                }
                return false;
            }
        });

        gallery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View v, int position, long id) {
                //클릭했을때 '+'인 경우 그전 이미지로 설정하고 그림판 액티비티로

                if(ga.putbitmap().size()==1){
                    startActivityForResult(albumIntent, REQ_CODE_SELECT_IMAGE);
                }
                else if((adapterView.getCount())==(position+1)){
                    imageView.setImageBitmap(ga.putbitmap().get(position-1));
                    startActivityForResult(albumIntent, REQ_CODE_SELECT_IMAGE);
                }
                else{
                    imageView.setImageBitmap(ga.putbitmap().get(position));
                }
            }
        });
        return view;
    }

    //Context Menu 생성
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if(v==gallery)
        {
            menu.setHeaderTitle(R.string.headerTitle);
            menu.add(0,1,0, R.string.gallery_menu_share);
            menu.add(0,2,0, R.string.gallery_menu_retouch);
            contextPosition=((AdapterView.AdapterContextMenuInfo)menuInfo).position;
        }
        else if(v==imageView)
        {
            menu.setHeaderTitle(R.string.headerTitle);
            menu.add(0,1,0, R.string.gallery_menu_share);
            menu.add(0,2,0, R.string.gallery_menu_retouch);
        }
    }

    //Context Menu 세부 설정
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Intent intent=null;
        GalleryActivity ga=new GalleryActivity();

        switch (item.getItemId())
        {
            case 1:
                intent=new Intent(Intent.ACTION_SEND);

                String path=ga.putImagePath().get(contextPosition);
                Uri uri=Uri.parse(StringSet.URI_STR+path);
                intent.putExtra(StringSet.INTENT_SET_NAME,StringSet.INTENT_SET_VAL);
                intent.putExtra(intent.EXTRA_STREAM, uri);
                intent.setType(StringSet.INTENT_TYPE);

                startActivity(intent);
            case 2:
                intent=new Intent(getActivity(), MainActivity.class);
                intent.putExtra(StringSet.INTENT_PICTURE, ga.putname().get(contextPosition));
                startActivity(intent);
                return true;
        }
        return true;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //GalleryActivity의 객체를 얻어옴
        GalleryActivity ga=new GalleryActivity();
        String path=ga.putDirPath();

        if(requestCode==REQ_CODE_SELECT_IMAGE){
            if(resultCode== Activity.RESULT_OK){
                try {
                    //GridViewFragment와 동일한 코드
                    //이미지를 albumd에서 가져와 bitmap ArrayList에 추가시키고 내부 저장소에 저장
                    Bitmap image_bitmap= MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), data.getData());
                    ImageForAlbum(image_bitmap, path, data.getData());
                } catch (FileNotFoundException e){
                    e.printStackTrace();
                } catch (IOException e){
                    e.printStackTrace();
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }



    public void ImageForAlbum(Bitmap bitmap, String dirPath, Uri data){
        //////////////////////////////////////////////
        String[] proj={MediaStore.Images.Media.DATA};
        GalleryActivity ga=new GalleryActivity();
        Cursor cursor=getContext().getContentResolver().query(data, proj, null, null, null);
        int column_index=cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

        ArrayList<String> compareList=ga.putname();

        cursor.moveToFirst();

        String imgPath=cursor.getString(column_index);
        String imgName=imgPath.substring(imgPath.lastIndexOf("/")+1);

        String path=dirPath+"/"+imgName;
        ///////////////////////////////////////
        if(compareList.contains(imgName)){
            Toast.makeText(getContext(), getResources().getString(R.string.alreadyExist),
                    Toast.LENGTH_LONG).show();
        }
        else{
            //가져올 이미지의 대한 정보를 미리 알아와
            BitmapFactory.Options options=new BitmapFactory.Options();

            //해당 정보를 가지고 이미지의 메모리사용량을 줄이기 위한 코드
            options.inJustDecodeBounds=false;
            options.inSampleSize=4; //해당 숫자를 수정하면 메모리사용량이줄어듬 4<5<6<7....
            options.inPurgeable=true;

            //얻어온 이미지를 다시 decode해서 adapterview에 뿌려줄 Bitmap ArrayList에 저장
            Bitmap tmpbit=BitmapFactory.decodeFile(imgPath, options);
            ga.addBitmap(tmpbit, imgPath, imgName);
            try {
                //위에서 얻은 경로를 이용해 비트맵을 저장시킴
                FileOutputStream out = new FileOutputStream(path);

                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.close();
            } catch (FileNotFoundException e){
                e.printStackTrace();
            } catch (IOException e){
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onStart() {
        super.onStart();
        gallery.setAdapter(new ImageAdapter(getActivity(), GALLERYVIEW));
    }

    public Gallery getGallery() {
        return gallery;
    }
}
