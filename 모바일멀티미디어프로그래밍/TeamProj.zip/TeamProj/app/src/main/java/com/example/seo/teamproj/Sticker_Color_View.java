package com.example.seo.teamproj;


import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.ColorDrawable;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Sticker_Color_View extends RelativeLayout {
    private Drawing drawing;
    public RecyclerView recyclerView;
    private StickerAdapter recyclerAdapter;
    private ImageButton button;
    private String dirPath;
    private Context mContext;

    //생성자들
    public Sticker_Color_View(Context context) {
        super(context);
        initialize(context);
    }
    public Sticker_Color_View(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initialize(context);
    }
    public Sticker_Color_View(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize(context);
    }
    public Sticker_Color_View(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initialize(context);
    }

    //초기화
    private void initialize(Context context){
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.sticker_color_view, this);

        initializeStickerRecyclerView(context);
        initializeHidingMenu(context);
        initializeAddNewSticker(context);
        initializeColorBar(context);
        initializeSizePicker(context);

    }

    //각종 기능(뷰그룹)별 초기화
    private void initializeStickerRecyclerView(final Context context) {
        mContext = context;

        recyclerView = findViewById(R.id.sticker_recycler_view);
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        linearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        linearLayoutManager.setStackFromEnd(false);
        recyclerView.setLayoutManager(linearLayoutManager);

        // 스티커 어댑터 초기화
        // 디렉토리에 있는 브러쉬를 가져온다

        //그림을 저장할 저장소 경로 가져오기

        dirPath= Environment.getExternalStorageDirectory()+"";
        String picPath=StringSet.FIRST_DIR+"/"+
                       StringSet.STICKER +"/";

        File dir=new File(dirPath, picPath);
        if(!dir.exists()){
            dir.mkdirs();
        }
        dirPath=dirPath+"/"+picPath;

        ArrayList<String> datas = new ArrayList<String>();

        ArrayList<String> names = null;
        File orderFile = new File(dirPath, StringSet.STICKER_ORDER);

        if (!orderFile.exists())
            names = new ArrayList<String>();
        else{
            try{
                FileInputStream fileInputStream = new FileInputStream(
                                       new File(dirPath+StringSet.STICKER_ORDER));

                ObjectInputStream in = new ObjectInputStream(fileInputStream);
                names = (ArrayList<String>) in.readObject();
                in.close();
                fileInputStream.close();
            }catch (IOException | ClassNotFoundException e){
                e.printStackTrace();
            }
        }

        recyclerAdapter = new StickerAdapter(names, context, 0);
        recyclerView.setAdapter(recyclerAdapter);
    }


    private void initializeHidingMenu(final Context context) {

        final RelativeLayout rl=findViewById(R.id.menu2_layout);
        final RelativeLayout color_bar=findViewById(R.id.color_bar);
        final ImageButton imageButton = findViewById(R.id.sticker_color_hide_button);
        final float y_value=rl.getTranslationY();

        imageButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                ImageButton imb=(ImageButton) v;

                boolean buttonState=imageButton.isSelected();
                buttonState=!buttonState;
                imageButton.setSelected(buttonState);

                if (buttonState) {

                    ValueAnimator moveAnim=ValueAnimator.ofFloat(y_value, 0);
                    moveAnim.setDuration(500);
                    moveAnim.setInterpolator(new AccelerateInterpolator());
                    moveAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                        @Override
                        public void onAnimationUpdate(ValueAnimator animation) {
                            rl.setTranslationY((float)animation.getAnimatedValue());
                            color_bar.setTranslationY((float)animation.getAnimatedValue());
                        }
                    });
                    moveAnim.start();
                }
                else {

                    ValueAnimator moveAnim=ValueAnimator.ofFloat(0, y_value);
                    moveAnim.setDuration(500);
                    moveAnim.setInterpolator(new AccelerateInterpolator());
                    moveAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                        @Override
                        public void onAnimationUpdate(ValueAnimator animation) {
                            rl.setTranslationY((float)animation.getAnimatedValue());
                            color_bar.setTranslationY((float)animation.getAnimatedValue());
                        }
                    });
                    moveAnim.start();
                }
            }
        });
    }
    private void initializeSizePicker(final Context context) {
        button=findViewById(R.id.size_picker);
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) context).sizeChangeDialog();
            }
        });
    }
    private void initializeColorBar(final Context context) {
        final LinearLayout color_picker=findViewById(R.id.color_picker);
        int size=getResources().getDimensionPixelSize(R.dimen.menu_size);

        for(int i=0; i<color_picker.getChildCount(); i++) {
            final ImageButton v=(ImageButton) color_picker.getChildAt(i);
            final int color=((ColorDrawable) v.getBackground()).getColor();

            Bitmap src=Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas=new Canvas(src);
            canvas.drawColor(color);

            Bitmap dest=BitmapFactory.decodeResource(getResources(), R.drawable.colormask);
            dest=Bitmap.createScaledBitmap(dest, size, size, false);

            Bitmap res=Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);

            Paint paint=new Paint();
            canvas=new Canvas(res);
            canvas.drawBitmap(dest, 0, 0, paint);

            PorterDuff.Mode mode=PorterDuff.Mode.SRC_OUT;
            paint.setXfermode(new PorterDuffXfermode(mode));

            canvas.drawBitmap(src, 0, 0, paint);
            v.setImageBitmap(res);
            v.setBackground(null);

            v.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    drawing.setPaintColor(color);
                }
            });
        }
    }
    private void initializeAddNewSticker(final Context context) {
        final ImageButton plus = findViewById(R.id.add_new_sticker);
        plus.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) context).start_brush();
            }
        });
    }

    //Drawing 객체의 Context 가져오기
    public void setDrawingC(Drawing drn) {
        drawing=drn;
        recyclerAdapter.setDrawing(drawing);
    }

    //사이즈 변경 버튼의 보이기 속성 제어
    public void setSizeButtonInvisible() {
        button.setVisibility(View.INVISIBLE);
    }
    public void setSizeButtonVisible() {
        button.setVisibility(View.VISIBLE);
    }

    // 새로운 스티커 파일 추가
    public void addStickerFileName(String name){
        recyclerAdapter.pushBackData(name);
    }

    public void saveSticker(){
        try{
            FileOutputStream fileOutputStream = new FileOutputStream(new File(dirPath+StringSet.STICKER_ORDER));
            ObjectOutputStream out = new ObjectOutputStream(fileOutputStream);

            ArrayList<StickerData> tmp = recyclerAdapter.getData();
            ArrayList<String> tmp2 = new ArrayList<String>();
            for (StickerData bd : tmp)
                tmp2.add(bd.getName());
            out.writeObject(tmp2);
            out.close();
            fileOutputStream.close();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
