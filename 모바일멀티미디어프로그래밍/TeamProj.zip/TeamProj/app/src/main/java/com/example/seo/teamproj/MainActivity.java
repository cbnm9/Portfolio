package com.example.seo.teamproj;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    public Drawing drawing;
    private Sticker_Color_View sticker_color_view;
    private Menu mMenu;
    public int currentMode;
    private boolean newFile;
    private String dirPath;
    private String imgPath;
    private Bitmap saveBitmap;
    private boolean ready;

    public static final int ADD_NEW_STICKER = 1;
    private static final int PERMISSION_STORAGE=10;

    //Undo, Redo 메뉴의 활성화/비활성화, Drawing.java 에서 호출
    public void doStateUpdate() {
        if(drawing.stateUndo()) {
            mMenu.findItem(R.id.undo).setEnabled(true);
        } else {
            mMenu.findItem(R.id.undo).setEnabled(false);
        }

        if(drawing.stateRedo()) {
            mMenu.findItem(R.id.redo).setEnabled(true);
        } else {
            mMenu.findItem(R.id.redo).setEnabled(false);
        }
    }

    //사이즈 변경 다이얼로그 - 다른 Java 소스에서 호출
    public void sizeChangeDialog() {
        final Dialog dialog=new Dialog(this);
        dialog.setContentView(R.layout.sizechangedialog);

        //설정한 크기를 저장할 변수, 현재 크기정보를 가져옴
        float result=drawing.sizeOfPaint(currentMode);

        final CustomViewForDialog customViewForDialog;
        customViewForDialog=(CustomViewForDialog) dialog.findViewById(R.id.custom_view_for_dialog);

        //다이얼로그의 모드정보 주기
        customViewForDialog.setMode(currentMode);

        //사이즈 조정용 SeekBar
        SeekBar seekBar=(SeekBar) dialog.findViewById(R.id.seek_bar_for_dialog);

        //모드별 값의 최대치 설정
        switch (currentMode) {
            case Drawing.FREE_LINE:
                seekBar.setMax(100);
                break;
            case Drawing.LINE:
                seekBar.setMax(100);
                break;
            case Drawing.STICKER:
                seekBar.setMax(300);
                break;
            case Drawing.ERASER:
                seekBar.setMax(200);
                break;
            case Drawing.TEXT:
                seekBar.setMax(200);
                break;
        }

        if(currentMode==Drawing.STICKER)
            customViewForDialog.setBitmap(drawing.getStickerBitmap());

        //초기 값 설정
        if(currentMode==Drawing.STICKER)
            customViewForDialog.setBitmapSize((int)result);
        else
            customViewForDialog.setSize(result);

        //seekBar 현재위치 설정
        seekBar.setProgress((int)result);

        //seekBar 이벤트 처리 : 크기변경하여 위에 커스텀뷰로 미리보기 보여줌
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(currentMode==Drawing.STICKER) {
                    //50보다 클때만 값 조정(비트맵 크기를 너무 줄일때 생기는 오류 방지)
                    if(progress>49)
                        customViewForDialog.setBitmapSize(progress);
                    else
                        customViewForDialog.setBitmapSize(50);
                }
                else
                    customViewForDialog.setSize((float) progress);

                customViewForDialog.invalidate();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        //확인 버튼 선택시 설정된 값으로 설정: Drawing 의 setPaintSize
        ((Button) dialog.findViewById(R.id.ok_button_for_dialog)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawing.setPaintSize(customViewForDialog.getmSize());
                dialog.dismiss();
            }
        });

        //취소 버튼 선택시 아무일도 일어나지 않고 다이얼로그 종료
        ((Button) dialog.findViewById(R.id.no_button_for_dialog)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    //도움말 다이얼로그
    public void helpDialog(){
        Dialog dialog=new Dialog(MainActivity.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        dialog.setContentView(R.layout.help_dialog);
        dialog.show();
    }

    //그림을 저장할 저장소 경로 가져오기
    private void PictureDirectory() {
        String dirPath= Environment.getExternalStorageDirectory()+"";
        String picPath=StringSet.FIRST_DIR+"/"+StringSet.PICTURE_DIR;

        File dir=new File(dirPath, picPath);
        if(!dir.exists()){
            dir.mkdirs();
        }
        dirPath=dirPath+"/"+picPath;
        this.dirPath=dirPath;
    }

    //저장하기 다이얼로그 - 새로만들기 또는 어플리케이션 종료할때
    public void saveDialog() {
        final Dialog dialog=new Dialog(this);
        dialog.setContentView(R.layout.saveconfirmdialog);
        dialog.setCancelable(false);

        ((Button) dialog.findViewById(R.id.OK_button_saveConfirmDialog)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(newFile)
                    saveAsDialog();
                else
                    saveFile();
                dialog.dismiss();
            }
        });

        ((Button) dialog.findViewById(R.id.NO_button_saveConfirmDialog)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ready=false;
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    //다른이름으로 저장하기 다이얼로그 - 새로만든 저장안된 그림 또는 다른이름으로 저장
    public void saveAsDialog() {
        final Dialog dialog=new Dialog(this);
        dialog.setContentView(R.layout.filenamedialog);
        dialog.setCancelable(false);

        ((Button) dialog.findViewById(R.id.OK_button_fileNameDialog)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text=((EditText) dialog.findViewById(R.id.edit_fileNameDialog)).getText().toString();

                if(text.isEmpty())
                    text=getResources().getString(R.string.UnTitle);

                text+=StringSet.PICTURE_FILE_FORM;
                imgPath=dirPath+"/"+text;

                saveFile();
                newFile=false;

                dialog.dismiss();
            }
        });

        ((Button) dialog.findViewById(R.id.NO_button_fileNameDialog)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    //저장하기 함수,
    public void saveFile() {
        saveBitmap=Bitmap.createBitmap(drawing.getBitmapForSave());
        (new FileSaveThread()).start();
    }

    //새 파일 선택시 저장하고 초기화하는 함수
    @SuppressLint("StaticFieldLeak")
    private void newFileMake() {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                while(ready);
                newFile=true;
                publishProgress();
                return null;
            }

            @Override
            protected void onProgressUpdate(Void... values) {
                drawing.newDrawing();
            }
        }.execute();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        checkPermission();

        //currentMode 의 초기값은 FreeLINE
        currentMode=Drawing.FREE_LINE;

        drawing=(Drawing) this.findViewById(R.id.draw);
        sticker_color_view =(Sticker_Color_View) this.findViewById(R.id.main_sticker_color_view);

        //내부 저장공간 경로 얻기
        PictureDirectory();

        //각 뷰에 필요한 정보 전달
        ((Tool_View)findViewById(R.id.main_tool_view)).setDrawingC(drawing);
        ((Sticker_Color_View)findViewById(R.id.main_sticker_color_view)).setDrawingC(drawing);
        ((Tool_View)findViewById(R.id.main_tool_view)).setBrush_color_view(sticker_color_view);

        //마지막으로 작업한 파일 가져오기
        SharedPreferences setting=getSharedPreferences(StringSet.SHARED_PREF_NAME, 0);
        imgPath=setting.getString(StringSet.SHARED_PREF_KEY, "");
        if(imgPath.isEmpty()) {
            newFile=true;
            return;
        }

        try {
            FileInputStream fileInputStream=new FileInputStream(imgPath);
            Bitmap btm=BitmapFactory.decodeStream(fileInputStream);
            drawing.initializeBitmap(btm);
            newFile=false;
            fileInputStream.close();
        } catch (FileNotFoundException e) {
            imgPath="";
            newFile=true;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        String fileName=intent.getStringExtra(StringSet.INTENT_PICTURE);
        if(fileName!=null) {
            String preImgPath=imgPath;
            imgPath=dirPath+"/"+fileName;
            try {
                FileInputStream fileInputStream=new FileInputStream(imgPath);
                Bitmap btm=BitmapFactory.decodeStream(fileInputStream);
                newFile=false;
                drawing.newDrawing();
                drawing.setRetouchBitmap(btm);
                fileInputStream.close();
            } catch (FileNotFoundException e) {
                Toast.makeText(getApplicationContext(),
                        getResources().getString(R.string.LoadPictureFail), Toast.LENGTH_SHORT).show();
                imgPath=preImgPath;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            //수정하기를 누른게 아니라면 아무 동작도 안함
        }

        initializeActivity();
        drawing.setMode(Drawing.FREE_LINE);
    }

    protected void initializeActivity() {
        //currentMode 의 초기값은 FreeLINE
        currentMode = Drawing.FREE_LINE;

        drawing = (Drawing) this.findViewById(R.id.draw);
        sticker_color_view = (Sticker_Color_View) this.findViewById(R.id.main_sticker_color_view);
        drawing.setMode(Drawing.FREE_LINE);

        ((Tool_View) findViewById(R.id.main_tool_view)).setDrawingC(drawing);
        ((Sticker_Color_View) findViewById(R.id.main_sticker_color_view)).setDrawingC(drawing);
        ((Tool_View) findViewById(R.id.main_tool_view)).setBrush_color_view(sticker_color_view);
    }

    @Override
    protected void onStop() {
        super.onStop();

        sticker_color_view.saveSticker();
    }

    //옵션메뉴 생성
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        mMenu=menu;
        getMenuInflater().inflate(R.menu.main_actionbarmenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //옵션메뉴 선택에 대한 이벤트 처리
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.undo:
                drawing.undo();
                return true;
            case R.id.redo:
                drawing.redo();
                return true;
            case R.id.make_new:
                if(drawing.isChanged()) {
                    saveDialog();
                    ready=true;
                } else {
                    ready=false;
                }
                newFileMake();
                return true;
            case R.id.gallery:
                if(drawing.isChanged()) {
                    saveDialog();
                    ready=true;
                } else {
                    ready=false;
                }
                start_gallery();
                return true;
            case R.id.save:
                if(newFile)
                    saveAsDialog();
                else
                    saveFile();
                return true;
            case R.id.save_as:
                saveAsDialog();
                return true;
            case R.id.help:
                helpDialog();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case ADD_NEW_STICKER:
                if(resultCode== Activity.RESULT_OK) {
                    String str=data.getStringExtra(StringSet.INTENT_STICKER);
                    sticker_color_view.addStickerFileName(str);
                } else {

                }
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                int pos=item.getOrder();
                ((StickerAdapter) sticker_color_view.recyclerView.getAdapter()).deleteData(pos);
                return true;
            default:
                break;
        }

        return super.onContextItemSelected(item);
    }

    //갤러리 엑티비티 호출
    private void start_gallery() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(ready);
                startActivity(new Intent(MainActivity.this, GalleryActivity.class));
            }
        }).start();
    }

    //스티커 엑티비티 호출
    public void start_brush() {
        if(drawing.isChanged()) {
            saveDialog();
            ready=true;
        } else {
            ready=false;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                while(ready);
                Intent intent = new Intent(MainActivity.this, StickerActivity.class);
                (MainActivity.this).startActivityForResult(intent, MainActivity.ADD_NEW_STICKER);
            }
        }).start();
    }

    //액티비티가 종료될때 마지막으로 작업한 그림 저장 및 경로 저장
    @Override
    protected void onDestroy() {
        super.onDestroy();

        SharedPreferences setting=getSharedPreferences(StringSet.SHARED_PREF_NAME,  0);
        SharedPreferences.Editor editor=setting.edit();
        editor.putString(StringSet.SHARED_PREF_KEY, imgPath);
        editor.commit();
    }

    public class FileSaveThread extends Thread {

        public void run() {

            while(true) {
                try {
                    FileOutputStream fileOutputStream=new FileOutputStream(imgPath);
                    saveBitmap.compress(Bitmap.CompressFormat.PNG, 0, fileOutputStream);
                    fileOutputStream.close();
                    break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            ready=false;
            handler.sendEmptyMessage(0);
        }

        //스레드 내에서 UI를 조작하기위한 핸들러
        @SuppressLint("HandlerLeak")
        private Handler handler=new Handler() {
            public void handleMessage(Message msg) {
                Toast.makeText(MainActivity.this,
                        getResources().getString(R.string.SaveSuccess), Toast.LENGTH_SHORT).show();
                super.handleMessage(msg);
            }
        };
    }

    //http://g-y-e-o-m.tistory.com/47
    //권한설정을 확인하기 위해 만든 함수
    public void checkPermission(){
        if(android.support.v4.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)!=
                android.content.pm.PackageManager.PERMISSION_GRANTED){

            android.support.v4.app.ActivityCompat.requestPermissions((Activity)this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_STORAGE);

        }
    }

    //checkpermission에서 권한설정을 하지 않은 경우 저장권한 비활성화 메세지 출력
    @Override
    public void onRequestPermissionsResult(int requestCode, @android.support.annotation.NonNull String[] permissions, @android.support.annotation.NonNull int[] grantResults) {
        switch (requestCode){
            case PERMISSION_STORAGE:
                for(int i=0;i<grantResults.length;i++){
                    //grantresult[]: 허용된 권한=0, 거부권한 = -1
                    if(grantResults[i]<0){
                        Toast.makeText(MainActivity.this,
                                getResources().getString(R.string.NoSavePermission),Toast.LENGTH_SHORT).show();

                        return;
                    }
                }
                break;
        }
    }
}
