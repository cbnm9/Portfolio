package com.example.seo.teamproj;

import android.animation.ValueAnimator;
import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

public class Tool_View extends RelativeLayout implements View.OnClickListener{

    private Context mContext;
    private Sticker_Color_View brush_color_view;
    private Drawing drawing=null;

    //배열을 사용하여 클릭이벤트 리스너셋팅 편하게 함
    private static int midSet[]={R.id.draw_freeLine, R.id.draw_line, R.id.draw_elli, R.id.draw_rect,
                                 R.id.draw_tri, R.id.draw_text, R.id.draw_sticker,
                                 R.id.draw_eraser};

    //생성자들
    public Tool_View(Context context) {
        super(context);
        initialize(context);
    }
    public Tool_View(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initialize(context);
    }
    public Tool_View(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize(context);
    }
    public Tool_View(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initialize(context);
    }

    //초기화
    private void initialize(Context context){

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.tool_view, this);

        initializeToolHideButton(context);

        //mContext 는 MainActivity 의 context
        mContext=context;

        //배열의 모든 버튼에 리스너 셋팅
        for(int id : midSet) {
            ((ImageButton) findViewById(id)).setOnClickListener(this);
        }
    }

    //슬라이딩 메뉴용 버튼 초기화
    private void initializeToolHideButton(Context context) {

        final RelativeLayout rl=findViewById(R.id.menu1_layout);
        final ImageButton imagebutton = findViewById(R.id.tool_hide_button);
        final float x_value=rl.getTranslationX();

        imagebutton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                ImageButton imb=(ImageButton) v;

                boolean buttonState=imb.isSelected();
                buttonState=!buttonState;
                imb.setSelected(buttonState);

                if (buttonState) {

                    ValueAnimator moveAnim=ValueAnimator.ofFloat(x_value, 0);
                    moveAnim.setDuration(500);
                    moveAnim.setInterpolator(new AccelerateInterpolator());
                    moveAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                        @Override
                        public void onAnimationUpdate(ValueAnimator animation) {
                            rl.setTranslationX((float)animation.getAnimatedValue());
                        }
                    });
                    moveAnim.start();
                }
                else {

                    ValueAnimator moveAnim=ValueAnimator.ofFloat(0, x_value);
                    moveAnim.setDuration(500);
                    moveAnim.setInterpolator(new AccelerateInterpolator());
                    moveAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                        @Override
                        public void onAnimationUpdate(ValueAnimator animation) {
                            rl.setTranslationX((float)animation.getAnimatedValue());
                        }
                    });
                    moveAnim.start();
                }
            }
        });
    }

    //버튼 클릭 이벤트 처리
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.draw_freeLine:
                drawing.setMode(Drawing.FREE_LINE);
                ((MainActivity) mContext).currentMode=Drawing.FREE_LINE;
                brush_color_view.setSizeButtonVisible();
                break;
            case R.id.draw_line:
                drawing.setMode(Drawing.LINE);
                ((MainActivity) mContext).currentMode=Drawing.LINE;
                brush_color_view.setSizeButtonVisible();
                break;
            case R.id.draw_rect:
                drawing.setMode(Drawing.RECT);
                ((MainActivity) mContext).currentMode=Drawing.RECT;
                brush_color_view.setSizeButtonInvisible();
                break;
            case R.id.draw_elli:
                drawing.setMode(Drawing.ELLI);
                ((MainActivity) mContext).currentMode=Drawing.ELLI;
                brush_color_view.setSizeButtonInvisible();
                break;
            case R.id.draw_tri:
                drawing.setMode(Drawing.TRI);
                ((MainActivity) mContext).currentMode=Drawing.TRI;
                brush_color_view.setSizeButtonInvisible();
                break;
            case R.id.draw_text:
                drawing.setMode(Drawing.TEXT);
                ((MainActivity) mContext).currentMode=Drawing.TEXT;
                brush_color_view.setSizeButtonVisible();
                break;
            case R.id.draw_sticker:
                drawing.setMode(Drawing.STICKER);
                ((MainActivity) mContext).currentMode=Drawing.STICKER;
                brush_color_view.setSizeButtonVisible();
                break;
            case R.id.draw_eraser:
                drawing.setMode(Drawing.ERASER);
                ((MainActivity) mContext).currentMode=Drawing.ERASER;
                brush_color_view.setSizeButtonVisible();
                break;
        }
    }

    //Drawing 객체의 Context 가져오기(MainActivity 에서 넘겨줌)
    public void setDrawingC(Drawing drn) {
        drawing=drn;
    }

    //Brush_Color_View 객체의 Context 가져오기
    public void setBrush_color_view(Sticker_Color_View bcv) {
        brush_color_view=bcv;
    }

}
