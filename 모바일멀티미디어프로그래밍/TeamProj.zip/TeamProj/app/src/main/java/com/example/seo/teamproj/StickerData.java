package com.example.seo.teamproj;

import android.graphics.Bitmap;

// 스티커 이름과 비트맵을 가지고 있는 클래스
// 비트맵이 필요할때만 가져오고 두번 가져오는 일 방지
public class StickerData {
    private String name;
    private Bitmap bitmap;

    public StickerData(String name){
        this.name = name;
        bitmap = null;
    }

    public String getName(){
        return name;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap){
        this.bitmap = bitmap;
    }

    public boolean isBitmapSet(){
        return bitmap != null;
    }
}
