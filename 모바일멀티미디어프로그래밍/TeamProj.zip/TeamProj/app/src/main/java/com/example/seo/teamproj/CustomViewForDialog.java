package com.example.seo.teamproj;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class CustomViewForDialog extends View {

    //그리기용 페인트 객체
    private Paint paint;
    private Paint paint_text;
    private Paint canvasPaint;
    private int mode;
    private Bitmap temp;
    private Bitmap bitmap;
    private float mSize;

    String sampleText=getResources().getString(R.string.sampleText);

    //생성자들
    public CustomViewForDialog(Context context) {
            super(context);
            setBackgroundColor(Color.WHITE);
            initialize();
    }
    public CustomViewForDialog(Context context, AttributeSet attrs) {
            super(context, attrs);
            setBackgroundColor(Color.WHITE);
            initialize();
    }
    public CustomViewForDialog(Context context, AttributeSet attrs, int defStyle) {
            super(context, attrs, defStyle);
            setBackgroundColor(Color.WHITE);
            initialize();
    }

    //초기화
    private void initialize() {
        paint=new Paint();
        paint.setColor(Color.BLACK);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);

        paint_text=new Paint();
        paint_text.setColor(Color.BLACK);
        paint_text.setAntiAlias(true);
        paint_text.setTextAlign(Paint.Align.CENTER);

        canvasPaint = new Paint(Paint.DITHER_FLAG);
    }

    //페인트 크기설정
    public void setSize(float size) {
        if(mode==Drawing.TEXT)
            paint_text.setTextSize(size);
        else
            paint.setStrokeWidth(size);

        //외부에서 size 필요할떄 넘겨주기위해 저장(다이얼로그 이벤트처리)
        mSize=size;
    }

    //비트맵 크기설정, temp: 크기 설정하기 전의 원본 비트맵
    public void setBitmapSize(float size) {
        bitmap=Bitmap.createScaledBitmap(temp, (int)size, (int)size, true);
        mSize=size;
    }

    //현재 이 커스텀뷰가 가지고있는 Size 정보 반환
    public float getmSize() {return mSize;}

    //비트맵 설정
    public void setBitmap(Bitmap btm) {
        if(btm==null)
            return;
        temp=Bitmap.createBitmap(btm);
    }

    //모드 설정
    public void setMode(int what) {
        mode=what;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        switch (mode) {
            case Drawing.FREE_LINE:
                canvas.drawColor(Color.WHITE);
                Path path=new Path();
                path.moveTo(this.getWidth()/2-150, this.getHeight()/2);
                path.cubicTo(this.getWidth()/2-50, this.getHeight(),
                             this.getWidth()/2+50, 0,
                             this.getWidth()/2+150, this.getHeight()/2);
                canvas.drawPath(path, paint);
                break;
            case Drawing.LINE:
                canvas.drawColor(Color.WHITE);
                canvas.drawLine(this.getWidth()/2-150, this.getHeight()/2,
                                this.getWidth()/2+150, this.getHeight()/2, paint);
                break;
            case Drawing.STICKER:
                canvas.drawColor(Color.WHITE);
                canvas.drawBitmap(bitmap, this.getWidth()/2-bitmap.getWidth()/2,
                                        this.getHeight()/2-bitmap.getHeight()/2, canvasPaint);
                break;
            case Drawing.TEXT:
                canvas.drawColor(Color.WHITE);
                canvas.drawText(sampleText, this.getWidth()/2,
                                                  this.getHeight()-20, paint_text);
                break;
            case Drawing.ERASER:
                canvas.drawColor(Color.BLACK);
                paint.setColor(Color.WHITE);
                canvas.drawLine(this.getWidth()/2-150, this.getHeight()/2,
                                this.getWidth()/2+150, this.getHeight()/2, paint);
                paint.setColor(Color.BLACK);
                break;
        }
    }
}
